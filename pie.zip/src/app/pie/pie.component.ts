import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pie',
  templateUrl: './pie.component.html',
  styleUrls: ['./pie.component.css']
})
export class PieComponent implements OnInit {
  public pieChartLabels = ['Debit_Amount - 150000', 'Credit_Amount - 100000' ];
  public pieChartData = [150, 100];
  public pieChartType = 'pie';
  constructor() { }

  ngOnInit() {
  }

}
