import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {ChartsModule} from 'ng2-charts';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PieComponent } from './pie/pie.component';
import { SapComponent } from './sap/sap.component';

@NgModule({
  declarations: [
    AppComponent,
    PieComponent,
    SapComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
